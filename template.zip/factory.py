import factory
from faker import Factory as FakerFactory

faker = FakerFactory().create()


