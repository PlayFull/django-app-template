from django.db import models, transaction
from django.utils.translation import ugettext_lazy as _


